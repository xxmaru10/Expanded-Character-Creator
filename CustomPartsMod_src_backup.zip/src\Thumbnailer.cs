using System;
using System.Reflection;
using UnityEngine;
using UnityUtils;
using RpgEngine.Characters;

namespace CustomPartsMod
{
    /// <summary>
    /// P7 — makes a part's tab-button icon by photographing JUST that part's mesh with its active
    /// texture (variant 0 by default), framed tight, on a transparent 512×512 background. Instead of
    /// spawning the part on the character, it drops a throwaway copy of the mesh far off-scene on an
    /// isolated layer and briefly retargets the engine's own (URP-correct) creator camera to it — one
    /// synchronous render, no visible flicker, camera fully restored afterwards. This means a part gets
    /// an icon whether it was just imported, mass-imported, or only rebuilt from a saved record (its
    /// mesh/texture are loaded on demand). Rendered UNLIT so the texture reads crisply as an icon and
    /// the result doesn't depend on scene lighting/probes.
    /// </summary>
    internal static class Thumbnailer
    {
        // A layer the isolated capture object lives on so the retargeted camera renders ONLY it.
        // Changed to 0 (Default) so URP pipeline culling doesn't discard the isolated render.
        private const int CaptureLayer = 0;

        /// <summary>Back-compat entry for the live edit panel: photographs the part behind the given
        /// attachment. Routes to the same off-screen renderer so every icon looks consistent.</summary>
        internal static void Capture(CustomBodyPartAttachment attachment)
        {
            if (attachment == null) return;
            CaptureFromPart(attachment.Part);
        }

        /// <summary>Renders <paramref name="part"/>'s mesh + active texture to a portrait and saves it as
        /// the part's icon (memory + disk). No-op if the mesh can't be loaded or the render fails (the
        /// button just stays in text mode, as before). Does NOT refresh the tab list — the caller owns
        /// that so this is safe to call from inside a button re-init.</summary>
        internal static void CaptureFromPart(CustomPart part)
        {
            if (part == null || string.IsNullOrEmpty(part.SourceKey)) return;

            part.EnsureLoaded(); // rebuilt-from-record parts parse their OBJ/texture here, on demand
            if (part.Mesh == null) return;

            var creator = UniqueMono<CharacterCreator>.instance;
            if (creator == null) return;

            Texture2D shot = RenderOffscreen(creator, part);
            if (shot == null || shot.height <= 1)
            {
                Plugin.Log.LogWarning("[thumb] render vazio; miniatura nao gerada para '" + part.SourceKey + "'.");
                return;
            }

            // Validate: reject fully transparent captures (camera wasn't ready / mesh was off-screen).
            // Sample a few pixels; if ALL are fully transparent the thumbnail is useless.
            bool hasContent = false;
            var pixels = shot.GetPixels32();
            int step = Mathf.Max(1, pixels.Length / 64); // sample ~64 pixels
            for (int i = 0; i < pixels.Length; i += step)
            {
                if (pixels[i].a > 10) { hasContent = true; break; }
            }
            if (!hasContent)
            {
                Plugin.Log.LogWarning("[thumb] captura completamente transparente; descartada para '" + part.SourceKey + "'.");
                part.ThumbnailProbed = false; // allow retry on next draw
                UnityEngine.Object.Destroy(shot);
                return;
            }

            part.Thumbnail = shot;
            part.ThumbnailSprite = null; // rebuilt lazily from the new texture
            ThumbnailStore.Save(part.SourceKey, shot);
        }

        /// <summary>Photographs the mesh off to the side with a temporary copy + the engine's camera.
        /// Returns null (caller falls back to text) if the camera isn't available or the render throws.</summary>
        private static Texture2D RenderOffscreen(CharacterCreator creator, CustomPart part)
        {
            var ccam = creator.creatorCam;
            var mainCam = ccam != null ? ccam.cam : null;
            if (mainCam == null) return null;

            Mesh mesh = part.Mesh;

            // Throwaway render object, far from the scene, on the isolated capture layer (Layer 0) so the camera
            // sees ONLY it.
            var root = new GameObject("__CustomParts_ThumbCapture") { layer = CaptureLayer };
            root.transform.position = new Vector3(0f, 100000f, 0f);
            root.transform.localScale = new Vector3(
                part.Scale * part.ScaleAxis.x,
                part.Scale * part.ScaleAxis.y,
                part.Scale * part.ScaleAxis.z);

            root.AddComponent<MeshFilter>().sharedMesh = mesh;
            var mr = root.AddComponent<MeshRenderer>();
            Material mat = BuildThumbMaterial(part.Texture);
            mr.sharedMaterial = mat;

            // Use the mesh's local bounds scaled manually to avoid Unity's same-frame MeshRenderer bounds update delay
            Bounds localBounds = mesh.bounds;
            Vector3 s = root.transform.localScale;

            // Calculate the actual world center and extents of the scaled object
            Vector3 center = root.transform.position + Vector3.Scale(localBounds.center, s);
            Vector3 extents = Vector3.Scale(localBounds.extents, s);

            float half = Mathf.Max(0.02f, Mathf.Max(Mathf.Abs(extents.x), Mathf.Max(Mathf.Abs(extents.y), Mathf.Abs(extents.z))));
            float fill = Mathf.Clamp(Plugin.ThumbnailFill.Value, 0.1f, 1f);

            // Create temporary camera dedicated for the thumbnail screenshot
            var camGo = new GameObject("__CustomParts_ThumbCam");
            var cam = camGo.AddComponent<Camera>();
            cam.fieldOfView = mainCam.fieldOfView;
            cam.orthographic = mainCam.orthographic;
            cam.orthographicSize = mainCam.orthographicSize;

            Component urp = FindUrpData(mainCam);
            Component tempUrp = null;
            PropertyInfo ppProp = null;
            if (urp != null)
            {
                tempUrp = cam.gameObject.AddComponent(urp.GetType());
                ppProp = tempUrp.GetType().GetProperty("renderPostProcessing");
            }

            RenderTexture rt = null;
            Texture2D shot = null;
            try
            {
                cam.cullingMask = 1 << CaptureLayer;
                cam.clearFlags = CameraClearFlags.SolidColor;
                cam.backgroundColor = new Color(0f, 0f, 0f, 0f); // transparent
                cam.aspect = 1f;

                // Fit the part's largest half-dimension to the target frame fraction, looking from a
                // yaw the user can flip (front by default) with a slight downward tilt for depth.
                float vfov = Mathf.Max(0.1f, cam.fieldOfView * Mathf.Deg2Rad);
                float dist = half / (fill * Mathf.Tan(vfov * 0.5f));
                Vector3 dir = Quaternion.Euler(0f, Plugin.ThumbnailYaw.Value, 0f) * Vector3.forward;
                
                // Position the camera looking at the mesh center from the calculated distance,
                // with a slight elevation for a better 3D preview angle.
                Vector3 camPos = center - dir * dist;
                camPos.y += half * 0.3f; // slight tilt down
                cam.transform.position = camPos;
                cam.transform.LookAt(center, Vector3.up);
                
                cam.nearClipPlane = 0.01f;
                cam.farClipPlane = dist + half * 4f + 10f;

                if (ppProp != null && ppProp.CanWrite) ppProp.SetValue(tempUrp, false);

                rt = new RenderTexture(512, 512, 24);
                cam.targetTexture = rt;
                cam.Render();

                shot = new Texture2D(rt.width, rt.height, TextureFormat.RGBA32, mipChain: false);
                RenderTexture.active = rt;
                shot.ReadPixels(new Rect(0f, 0f, rt.width, rt.height), 0, 0);
                shot.Apply();
                RenderTexture.active = null;
            }
            catch (Exception e)
            {
                Plugin.Log.LogWarning("[thumb] falha ao fotografar a peca: " + e.Message);
                shot = null;
            }
            finally
            {
                if (rt != null) { RenderTexture.active = null; rt.Release(); UnityEngine.Object.Destroy(rt); }
                if (mat != null) UnityEngine.Object.Destroy(mat);
                if (root != null) UnityEngine.Object.Destroy(root);
                if (camGo != null) UnityEngine.Object.Destroy(camGo);
            }

            return shot;
        }

        private static Material BuildThumbMaterial(Texture2D tex)
        {
            Shader sh = Shader.Find("Universal Render Pipeline/Lit")
                        ?? Shader.Find("Standard")
                        ?? Shader.Find("Sprites/Default");
            var m = new Material(sh);
            if (tex != null)
            {
                m.mainTexture = tex;
                if (m.HasProperty("_BaseMap")) m.SetTexture("_BaseMap", tex);
                if (m.HasProperty("_MainTex")) m.SetTexture("_MainTex", tex);
                if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", Color.white);
                if (m.HasProperty("_Color")) m.SetColor("_Color", Color.white);
                
                // Set emission properties to make the material render lit/glowing in darkness (unlit effect)
                if (m.HasProperty("_EmissionMap")) m.SetTexture("_EmissionMap", tex);
                if (m.HasProperty("_EmissionColor")) m.SetColor("_EmissionColor", Color.white);
                m.EnableKeyword("_EMISSION");
            }
            else
            {
                Color grey = new Color(0.72f, 0.72f, 0.75f, 1f);
                if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", grey);
                if (m.HasProperty("_Color")) m.SetColor("_Color", grey);
                
                // Set emission properties for solid gray untextured parts
                if (m.HasProperty("_EmissionColor")) m.SetColor("_EmissionColor", grey);
                m.EnableKeyword("_EMISSION");
            }
            return m;
        }

        private static Component FindUrpData(Camera cam)
        {
            foreach (var c in cam.GetComponents<Component>())
                if (c != null && c.GetType().Name == "UniversalAdditionalCameraData") return c;
            return null;
        }
    }
}
