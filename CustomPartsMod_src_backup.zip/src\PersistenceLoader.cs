using System;
using System.IO;
using UnityEngine;
using UnityUtils;
using RpgEngine.Characters;
using RiggedAttachType = RpgEngine.Characters.CharacterCreatorEnums.RiggedAttachType;

namespace CustomPartsMod
{
    /// <summary>
    /// P0 — persistence across sessions. On the first time the creator opens, re-registers every saved
    /// model (those confirmed via the panel) so custom parts survive a restart. Registration uses the
    /// saved record's METADATA only — no OBJ is parsed and no PNG is decoded here. The mesh + texture are
    /// imported lazily by <see cref="CustomPart.EnsureLoaded"/> the first time the part is applied, which
    /// keeps opening the creator fast even with thousands of saved parts.
    /// </summary>
    internal static class PersistenceLoader
    {
        private static bool _loaded;

        internal static void LoadAll(CharacterCreator creator)
        {
            if (_loaded) return; // once per session; parts stay registered afterwards
            _loaded = true;

            if (creator == null || creator.itemTabsLoader == null) return;

            int ok = 0, fail = 0;
            foreach (var kv in ScaleStore.AllModels())
            {
                try { if (Register(kv.Key, kv.Value)) ok++; else fail++; }
                catch (Exception e) { fail++; Plugin.Log.LogWarning("[persist] '" + kv.Key + "': " + e.Message); }
            }

            if (ok > 0) creator.itemTabsLoader.Refresh();
            Plugin.Log.LogInfo($"[persist] {ok} modelo(s) registrado(s), {fail} pulado(s).");
        }

        private static bool Register(string sourceKey, PartTransform rec)
        {
            if (rec.category == null || rec.category.Length == 0)
                return false; // pre-P0 record without category; user re-confirms once to upgrade it

            // Cheap existence check (a stat, not a parse) so a moved/deleted model doesn't leave a dead
            // button in the tab. The actual geometry/texture load is deferred to EnsureLoaded.
            if (string.IsNullOrEmpty(rec.modelPath) || !File.Exists(rec.modelPath))
            {
                Plugin.Log.LogWarning("[persist] arquivo do modelo ausente: " + rec.modelPath);
                return false;
            }

            RiggedAttachType slot = RiggedAttachType.head;
            if (!string.IsNullOrEmpty(rec.slot)) Enum.TryParse(rec.slot, out slot);

            // P13 — restore the texture variant list + active index. Paths only; the active texture is
            // decoded lazily on first apply (EnsureLoaded).
            var variants = new System.Collections.Generic.List<string>();
            if (rec.textureVariants != null)
                foreach (var v in rec.textureVariants) if (!string.IsNullOrEmpty(v)) variants.Add(v);
            if (variants.Count == 0 && !string.IsNullOrEmpty(rec.texturePath)) variants.Add(rec.texturePath);
            int activeVariant = variants.Count > 0 ? Mathf.Clamp(rec.activeVariant, 0, variants.Count - 1) : 0;
            string activePath = variants.Count > 0 ? variants[activeVariant] : null;

            var part = new CustomPart
            {
                PartId = ImportFlow.MakeId(sourceKey),
                SourceKey = sourceKey,
                ModelPath = rec.modelPath,
                DisplayName = Path.GetFileNameWithoutExtension(rec.modelPath),
                CategoryPath = rec.category,
                Slot = slot,
                ChannelId = !string.IsNullOrEmpty(rec.channel) ? rec.channel : ChannelMap.ForCategory(rec.category), // P2
                Tag = rec.tag ?? "", // P10 user tag/theme
                Mesh = null,          // imported lazily on first apply
                Texture = null,       // decoded lazily on first apply
                TexturePath = activePath,
                TextureVariants = variants,
                ActiveVariant = activeVariant,
                Scale = rec.scale,
                NormalizedScale = 1f, // recomputed with the mesh in EnsureLoaded (only used when re-editing)
                ScaleAxis = rec.scaleAxis,
                LocalPosition = rec.offset,
                LocalEuler = rec.euler,
                GenderTag = rec.gender ?? "",
                AdditiveOverride = rec.additive,
                LinkGroupId = rec.link ?? "",
                Additive = AccessoryMap.ResolveAdditive(rec.category, rec.additive), // eyes/accessories stay additive on reload (P14)
            };

            CustomPartCatalog.Register(part);                     // -> attachmentPaths, becomes an option
            Compat.AddTabInitializer(UniqueMono<CharacterCreator>.instance.itemTabsLoader, part.PartId);
            return true;
        }
    }
}
