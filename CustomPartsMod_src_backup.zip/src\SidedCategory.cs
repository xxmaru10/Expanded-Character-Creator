using System;
using RiggedAttachType = RpgEngine.Characters.CharacterCreatorEnums.RiggedAttachType;

namespace CustomPartsMod
{
    /// <summary>
    /// The engine splits some limbs into separate left/right sockets (legLowerL/R for legs+feet,
    /// handL/R for hands). When importing into one of these categories the user must pick a side
    /// (see <see cref="SidePrompt"/>); this identifies those categories (language-independent, by
    /// savePath segment) and maps each to its left/right slot pair. Feet and shoes share one "Feet" kind
    /// (a shoe stacks on the chosen foot); hands are their own kind — each kind remembers its own
    /// last-used side independently (see <see cref="ScaleStore.GetLastSideLeft"/>).
    /// </summary>
    internal static class SidedCategory
    {
        internal enum Kind { None, Feet, Hands, ArmUpper, ArmLower, Knees }

        internal static Kind KindOf(string[] category)
        {
            if (category == null) return Kind.None;
            foreach (var s in category)
            {
                if (Eq(s, "feet") || Eq(s, "shoes") || Eq(s, "lowerlegs") || Eq(s, "legs") || Eq(s, "foot")) return Kind.Feet;
                if (Eq(s, "hands")) return Kind.Hands;
                if (Eq(s, "uppers")) return Kind.ArmUpper;                              // upper arm (braço)
                if (Eq(s, "wrists") || Eq(s, "elbows") || Eq(s, "arms")) return Kind.ArmLower; // forearm (antebraço)
                if (Eq(s, "knees")) return Kind.Knees;                                   // knees (joelho/coxa)
            }
            return Kind.None;
        }

        internal static bool AppliesTo(string[] category) => KindOf(category) != Kind.None;

        internal static RiggedAttachType LeftSlot(Kind kind)
        {
            switch (kind)
            {
                case Kind.Hands:    return RiggedAttachType.handL;
                case Kind.ArmUpper: return RiggedAttachType.armUpperL;
                case Kind.ArmLower: return RiggedAttachType.armLowerL;
                case Kind.Knees:    return RiggedAttachType.kneeL;
                default:            return RiggedAttachType.legLowerL; // Feet
            }
        }

        internal static RiggedAttachType RightSlot(Kind kind)
        {
            switch (kind)
            {
                case Kind.Hands:    return RiggedAttachType.handR;
                case Kind.ArmUpper: return RiggedAttachType.armUpperR;
                case Kind.ArmLower: return RiggedAttachType.armLowerR;
                case Kind.Knees:    return RiggedAttachType.kneeR;
                default:            return RiggedAttachType.legLowerR; // Feet
            }
        }

        /// <summary>Stable key (independent of language) used to remember each kind's last-used side
        /// separately, so choosing one limb's side doesn't affect the others' remembered side.</summary>
        internal static string StoreKey(Kind kind)
        {
            switch (kind)
            {
                case Kind.Hands:    return "hands";
                case Kind.ArmUpper: return "armupper";
                case Kind.ArmLower: return "armlower";
                case Kind.Knees:    return "knees";
                default:            return "feet";
            }
        }

        internal static string PanelTitle(Kind kind)
        {
            switch (kind)
            {
                case Kind.Hands:    return "Lado da mão";
                case Kind.ArmUpper: return "Lado do braço";
                case Kind.ArmLower: return "Lado do antebraço";
                case Kind.Knees:    return "Lado do joelho";
                default:            return "Lado do pé";
            }
        }

        internal static string Question(Kind kind)
        {
            switch (kind)
            {
                case Kind.Hands:    return "Este modelo é para qual mão?";
                case Kind.ArmUpper: return "Este modelo é para qual braço?";
                case Kind.ArmLower: return "Este modelo é para qual antebraço?";
                case Kind.Knees:    return "Este modelo é para qual joelho/coxa?";
                default:            return "Este modelo é para qual pé?";
            }
        }

        private static bool Eq(string a, string b) => string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
    }
}
