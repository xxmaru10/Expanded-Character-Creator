using UnityUtils;   // ConvertToSprite
using RpgEngine;    // BuildTabsButton
using UnityEngine;

namespace CustomPartsMod
{
    /// <summary>
    /// P7 — replaces a custom part's tab button TEXT with its snapshot portrait. Runs from the same
    /// per-item postfix as the trash/edit buttons, AFTER the engine's InitialiseButton has set the
    /// button to text mode (custom parts have no real Resources icon, so they default to text). Only
    /// touches custom parts that actually have a thumbnail; native parts and un-snapshotted customs are
    /// left as the engine drew them. Pool-safe: each re-init runs InitialiseButton first (resetting to
    /// text), so nothing needs undoing here.
    /// </summary>
    internal static class IconButton
    {
        internal static void Apply(BuildTabsButton button, string id)
        {
            if (button == null || button.icon == null || button.text == null) return;

            if (!CustomPartCatalog.TryGet(id, out var part))
            {
                // Restore native button state (recycled buttons need their native icon active and text inactive)
                button.icon.SetActive(true);
                button.text.SetActive(false);
                return;
            }

            // Load the saved portrait from disk lazily, the first time this part's button is drawn (the
            // scroll pool only inits visible buttons), instead of eagerly at registration — that keeps
            // opening the creator cheap with a large library. Probed once; a portrait made later this
            // session (Thumbnailer) sets part.Thumbnail directly and shows without another disk hit.
            if (part.Thumbnail == null && !part.ThumbnailProbed)
            {
                part.ThumbnailProbed = true;
                // Prefer a picture already saved for this model; otherwise generate one NOW by
                // photographing the mesh + its texture (variant 0). This gives every part a model icon
                // instead of its name — imported, mass-imported, or reloaded from a saved record —
                // without the user having to open each one. Generated once, then cached to disk.
                if (ThumbnailStore.TryLoad(part.SourceKey, out var thumb)) part.Thumbnail = thumb;
                else Thumbnailer.CaptureFromPart(part);
            }

            if (part.Thumbnail == null)
            {
                // Fallback to text if thumbnail generation failed (or transparent capture discarded)
                button.icon.SetActive(false);
                button.text.SetActive(true);
                return;
            }

            if (part.ThumbnailSprite == null)
                part.ThumbnailSprite = part.Thumbnail.ConvertToSprite();

            button.icon.SetImage(part.ThumbnailSprite);
            button.icon.SetActive(true);
            button.text.SetActive(false);
        }
    }
}

