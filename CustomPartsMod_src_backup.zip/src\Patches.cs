using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using UnityUtils;
using RpgEngine;
using RpgEngine.Characters;
using RiggedAttachType = RpgEngine.Characters.CharacterCreatorEnums.RiggedAttachType;

namespace CustomPartsMod
{
    /// <summary>
    /// Intercepts PickupableCharacter.AddPart(string) for custom ids: builds the mesh
    /// attachment at runtime instead of the vanilla Resources.Load path, then reuses the
    /// engine's own private registration + colour application so behaviour matches vanilla.
    /// </summary>
    [HarmonyPatch]
    internal static class Patch_AddPart
    {
        private static MethodBase TargetMethod()
            => AccessTools.Method(typeof(PickupableCharacter), nameof(PickupableCharacter.AddPart), new[] { typeof(string) });

        private static bool _isAutoLinking = false;

        private static bool Prefix(PickupableCharacter __instance, string partId, ref CharacterAttachment __result)
        {
            bool isCustom = CustomPartCatalog.TryGet(partId, out var part);

            // Replace, don't stack: clear any CUSTOM part already occupying this slot before adding.
            // A native part only clears its own attach socket; our custom part lives on the animated
            // bone, so selecting a native part in the same slot would otherwise leave the custom one on.
            //
            // BUT an ADDITIVE part (an accessory, P14) must add ON TOP of whatever is in the slot — e.g. a
            // crown/horns over an already-imported custom HEAD (same bone). So an additive incoming part
            // never clears the slot; it just stacks. (Removing an accessory is done by clicking it again.)
            bool incomingAdditive = isCustom && part.Additive;
            if (!incomingAdditive && TryGetIncomingSlot(partId, isCustom ? part : null, out var slot))
                RemoveCustomInSlot(__instance, slot, keepId: partId);

            if (!isCustom)
            {
                if (partId != null && partId.StartsWith("CustomPart_"))
                {
                    // The catalog may not be populated yet (map loads before the Character Creator opens).
                    // Try to reconstruct this part on-demand from the persistence store (scales.json).
                    part = TryLoadOnDemand(partId);
                    if (part != null)
                    {
                        isCustom = true;
                        // fall through to the normal custom-part build path below
                    }
                    else
                    {
                        Plugin.Log.LogWarning($"Part '{partId}' not found in CustomPartCatalog and could not be loaded from persistence. Skipping.");
                        __result = null;
                        return false; // truly missing — skip to avoid crash
                    }
                }
                else
                {
                    return true; // not ours: run the original
                }
            }

            // Build never returns null; assign __result before the (reflection) registration so
            // that even if registration throws, SpawnAlongside's `.gameObject` deref is safe.
            var attachment = CustomBodyPartAttachment.Build(part, __instance);
            __result = attachment;

            try
            {
                Compat.InvokeSetAllOn(__instance, attachment);        // apply current colours
                Compat.InvokeAddPart(__instance, partId, attachment);  // register in attachedItems + prop
            }
            catch (Exception e)
            {
                Plugin.Log.LogError("Falha ao registrar parte customizada '" + partId + "': " + e);
            }

            // Auto-equip linked parts (children) when a trigger part (torso or hips) is explicitly equipped
            if (!_isAutoLinking && !string.IsNullOrEmpty(part.LinkGroupId) && 
                (part.Slot == RiggedAttachType.hip || part.Slot == RiggedAttachType.torso))
            {
                _isAutoLinking = true;
                try
                {
                    var creator = UniqueMono<CharacterCreator>.instance;
                    foreach (var p in CustomPartCatalog.AllParts())
                    {
                        if (p.PartId != part.PartId && p.LinkGroupId == part.LinkGroupId)
                        {
                            if (creator != null && creator.dummy != null)
                            {
                                if (!creator.dummy.Contains(p.PartId))
                                {
                                    creator.SpawnAlongside(p.PartId);
                                }
                            }
                            else
                            {
                                __instance.AddPart(p.PartId);
                            }
                        }
                    }
                }
                finally
                {
                    _isAutoLinking = false;
                }
            }

            return false; // skip original
        }

        /// <summary>Slot the incoming part occupies: from the custom part if ours, else derived from
        /// the native part's savePath. Returns false when the slot can't be identified confidently.</summary>
        internal static bool TryGetIncomingSlot(string partId, CustomPart custom, out RiggedAttachType slot)
        {
            if (custom != null) { slot = custom.Slot; return true; }
            slot = default;
            if (!CharacterCreator.attachmentPaths.TryGetValue(partId, out var data)
                || data.savePath == null
                || !CategoryMap.TryToSocket(data.savePath.ToArray(), out slot))
                return false;

            // CategoryMap defaults to the R variant for sided slots. If the native part's savePath
            // or partId contains a left-side indicator, flip to the L variant so RemoveCustomInSlot
            // matches the correct side.
            string path = string.Join("/", data.savePath).ToLowerInvariant();
            string pid = partId.ToLowerInvariant();
            bool isLeft = path.Contains("left") || path.Contains("_l/") || path.Contains("_l_")
                       || pid.Contains("left") || pid.Contains("_l_") || pid.EndsWith("_l");

            if (isLeft)
            {
                slot = FlipToLeft(slot);
            }
            return true;
        }

        /// <summary>Converts a right-side slot to its left counterpart.</summary>
        private static RiggedAttachType FlipToLeft(RiggedAttachType slot)
        {
            switch (slot)
            {
                case RiggedAttachType.handR: return RiggedAttachType.handL;
                case RiggedAttachType.armUpperR: return RiggedAttachType.armUpperL;
                case RiggedAttachType.armLowerR: return RiggedAttachType.armLowerL;
                case RiggedAttachType.shoulderR: return RiggedAttachType.shoulderL;
                case RiggedAttachType.legLowerR: return RiggedAttachType.legLowerL;
                default: return slot;
            }
        }

        /// <summary>Unequips (from the preview only) any custom part sitting in <paramref name="slot"/>,
        /// except <paramref name="keepId"/> — so a newly selected part replaces it instead of stacking.</summary>
        private static void RemoveCustomInSlot(PickupableCharacter character, RiggedAttachType slot, string keepId)
        {
            List<string> toRemove = null;
            foreach (var kv in character.attachedItems)
            {
                if (kv.Key == keepId) continue;
                // Additive parts (eyes) are never auto-removed by placing another part — they only come
                // off when the user clicks them again. Skip them here.
                if (kv.Value is CustomBodyPartAttachment c && c.Part != null && !c.Part.Additive && c.Part.Slot == slot)
                    (toRemove ?? (toRemove = new List<string>())).Add(kv.Key);
            }
            if (toRemove == null) return;
            foreach (var id in toRemove)
            {
                try { character.RemovePart(id); }
                catch (Exception e) { Plugin.Log.LogWarning("substituir slot: " + e.Message); }
            }
        }

        /// <summary>Reconstructs a CustomPart from the persistence store (scales.json) when the
        /// catalog hasn't been populated yet (map loads before the Character Creator opens).
        /// Returns null if the part truly doesn't exist on disk.</summary>
        private static CustomPart TryLoadOnDemand(string partId)
        {
            // Walk all saved models looking for one whose MakeId matches our partId.
            foreach (var kv in ScaleStore.AllModels())
            {
                string expectedId = ImportFlow.MakeId(kv.Key);
                if (!string.Equals(expectedId, partId, StringComparison.Ordinal)) continue;

                var rec = kv.Value;

                // File must still exist on disk.
                if (string.IsNullOrEmpty(rec.modelPath) || !System.IO.File.Exists(rec.modelPath))
                    return null;

                if (rec.category == null || rec.category.Length == 0)
                    return null;

                RiggedAttachType slot = RiggedAttachType.head;
                if (!string.IsNullOrEmpty(rec.slot)) Enum.TryParse(rec.slot, out slot);

                var variants = new List<string>();
                if (rec.textureVariants != null)
                    foreach (var v in rec.textureVariants) if (!string.IsNullOrEmpty(v)) variants.Add(v);
                if (variants.Count == 0 && !string.IsNullOrEmpty(rec.texturePath)) variants.Add(rec.texturePath);
                int activeVariant = variants.Count > 0 ? Mathf.Clamp(rec.activeVariant, 0, variants.Count - 1) : 0;
                string activePath = variants.Count > 0 ? variants[activeVariant] : null;

                var part = new CustomPart
                {
                    PartId = partId,
                    SourceKey = kv.Key,
                    ModelPath = rec.modelPath,
                    DisplayName = System.IO.Path.GetFileNameWithoutExtension(rec.modelPath),
                    CategoryPath = rec.category,
                    Slot = slot,
                    ChannelId = !string.IsNullOrEmpty(rec.channel) ? rec.channel : ChannelMap.ForCategory(rec.category),
                    Tag = rec.tag ?? "",
                    Mesh = null,
                    Texture = null,
                    TexturePath = activePath,
                    TextureVariants = variants,
                    ActiveVariant = activeVariant,
                    Scale = rec.scale,
                    NormalizedScale = 1f,
                    ScaleAxis = rec.scaleAxis,
                    LocalPosition = rec.offset,
                    LocalEuler = rec.euler,
                    GenderTag = rec.gender ?? "",
                    AdditiveOverride = rec.additive,
                    LinkGroupId = rec.link ?? "",
                    Additive = AccessoryMap.ResolveAdditive(rec.category, rec.additive),
                };

                CustomPartCatalog.Register(part);
                Plugin.Log.LogInfo($"[on-demand] Part '{partId}' loaded from persistence for map character.");
                return part;
            }
            return null;
        }
    }

    /// <summary>
    /// After ANY part is placed, re-add wanted additive parts (eyes) the engine may have removed as
    /// collateral (native head/face placement clears its socket via RemoveAllChildren). See
    /// <see cref="AdditiveParts"/>. Runs for native and custom AddPart alike; guarded against recursion.
    /// </summary>
    [HarmonyPatch]
    internal static class Patch_AddPart_Reapply
    {
        private static MethodBase TargetMethod()
            => AccessTools.Method(typeof(PickupableCharacter), nameof(PickupableCharacter.AddPart), new[] { typeof(string) });

        private static void Postfix(PickupableCharacter __instance) => AdditiveParts.Reapply(__instance);
    }

    /// <summary>
    /// The user's ON/OFF intent for an additive part is expressed by clicking it (SpawnAlongside toggles
    /// it). Record that intent BEFORE the toggle so collateral removals don't clear it.
    /// </summary>
    [HarmonyPatch(typeof(CharacterCreator), nameof(CharacterCreator.SpawnAlongside))]
    internal static class Patch_SpawnAlongside_Additive
    {
        private static void Prefix(CharacterCreator __instance, string item)
        {
            if (__instance.dummy == null) return;
            if (!CustomPartCatalog.TryGet(item, out var part) || !part.Additive) return;
            // Original toggles: Contains => it will be removed; else it will be added.
            AdditiveParts.SetIntent(item, !__instance.dummy.Contains(item));
        }
    }

    /// <summary>
    /// P13 — after a part is clicked (SpawnAlongside toggles it), show the top-center texture-variant
    /// bar for it when it is a custom part now applied; otherwise hide the bar (native part, or the
    /// custom part was toggled off). NavArrows' off-then-on pair ends with the target shown.
    /// </summary>
    [HarmonyPatch(typeof(CharacterCreator), nameof(CharacterCreator.SpawnAlongside))]
    internal static class Patch_SpawnAlongside_VariantBar
    {
        private static void Postfix(CharacterCreator __instance, string item)
        {
            if (__instance.dummy == null) return;
            if (__instance.dummy.attachedItems.TryGetValue(item, out var att) && att is CustomBodyPartAttachment c)
                VariantBar.ShowFor(c);
            else
                VariantBar.Hide();
        }
    }

    /// <summary>Reset (the "reset parts" button / new character) clears additive intent so eyes don't
    /// get re-applied onto a freshly reset character.</summary>
    [HarmonyPatch(typeof(CharacterCreator), nameof(CharacterCreator.ResetParts))]
    internal static class Patch_ResetParts_Additive
    {
        private static void Prefix() => AdditiveParts.Clear();
    }

    /// <summary>
    /// PickupableCharacter.Contains(string) would hit Resources.Load for a custom id and
    /// throw; answer from attachedItems instead.
    /// </summary>
    [HarmonyPatch]
    internal static class Patch_Contains
    {
        private static MethodBase TargetMethod()
            => AccessTools.Method(typeof(PickupableCharacter), nameof(PickupableCharacter.Contains), new[] { typeof(string) });

        private static bool Prefix(PickupableCharacter __instance, string partId, ref bool __result)
        {
            if (!CustomPartCatalog.IsCustom(partId))
                return true;

            __result = __instance.attachedItems.ContainsKey(partId);
            return false;
        }
    }

    internal static class Patch_SpawnAlongside_State
    {
        internal static bool IsSpawning = false;
        internal static string SpawningPartId = null;
    }

    [HarmonyPatch(typeof(CharacterCreator), nameof(CharacterCreator.SpawnAlongside))]
    internal static class Patch_SpawnAlongside_Tracker
    {
        private static void Prefix(string item)
        {
            Patch_SpawnAlongside_State.IsSpawning = true;
            Patch_SpawnAlongside_State.SpawningPartId = item;
        }

        private static void Postfix()
        {
            Patch_SpawnAlongside_State.IsSpawning = false;
            Patch_SpawnAlongside_State.SpawningPartId = null;
        }
    }

    [HarmonyPatch(typeof(PickupableCharacter), nameof(PickupableCharacter.RemovePart), new[] { typeof(string) })]
    internal static class Patch_RemovePart_Guard
    {
        private static bool Prefix(PickupableCharacter __instance, string partId)
        {
            // If the removal is triggered during a SpawnAlongside call (UI button selection):
            if (Patch_SpawnAlongside_State.IsSpawning && !string.IsNullOrEmpty(Patch_SpawnAlongside_State.SpawningPartId))
            {
                string incomingId = Patch_SpawnAlongside_State.SpawningPartId;
                if (CustomPartCatalog.TryGet(partId, out var oldPart))
                {
                    if (CustomPartCatalog.TryGet(incomingId, out var newPart))
                    {
                        var oldKind = SidedCategory.KindOf(oldPart.CategoryPath);
                        var newKind = SidedCategory.KindOf(newPart.CategoryPath);
                        if (oldKind != SidedCategory.Kind.None && oldKind == newKind)
                        {
                            // If they are on different slots (e.g. L vs R), do NOT allow the UI to auto-remove the old part!
                            if (oldPart.Slot != newPart.Slot)
                            {
                                return false; // skip the removal
                            }
                        }
                    }
                    else if (Patch_AddPart.TryGetIncomingSlot(incomingId, null, out var incomingSlot))
                    {
                        // Incoming is a native part; only allow removal if they share the same slot (side)
                        if (oldPart.Slot != incomingSlot)
                        {
                            return false; // skip the removal
                        }
                    }
                }
            }
            return true;
        }
    }

    /// <summary>
    /// P2 — user painting. PickupableCharacter.SetColor(string,Color) is the broadcast fired when the
    /// user moves a colour picker (NOT on the initial SetAllOn, which applies colours part-directly).
    /// So this fires only on deliberate paint: tint each textured custom part whose channel matches.
    /// </summary>
    [HarmonyPatch]
    internal static class Patch_Paint
    {
        private static MethodBase TargetMethod()
            => AccessTools.Method(typeof(PickupableCharacter), nameof(PickupableCharacter.SetColor), new[] { typeof(string), typeof(Color) });

        private static void Postfix(PickupableCharacter __instance, string target, Color color)
        {
            foreach (var kv in __instance.attachedItems)
                if (kv.Value is CustomBodyPartAttachment c && c.Part != null && c.Part.ChannelId == target)
                    c.ApplyPaint(color);
        }
    }

    /// <summary>
    /// Textured custom parts are painted via <see cref="Patch_Paint"/>; their lit material has no
    /// _Color_* channel properties. Skip the engine's per-channel SetColor for them (avoids setting
    /// missing properties). Untextured custom parts + native parts run the original.
    /// </summary>
    [HarmonyPatch]
    internal static class Patch_AttachmentColor
    {
        private static MethodBase TargetMethod()
            => AccessTools.Method(typeof(CharacterAttachment), "SetColor", new[] { typeof(string), typeof(Color) });

        private static bool Prefix(CharacterAttachment __instance)
            => !(__instance is CustomBodyPartAttachment c && c.HasTint);
    }

    /// <summary>
    /// After the creator window is populated, make sure the Import button exists.
    /// </summary>
    [HarmonyPatch(typeof(CharacterCreator), nameof(CharacterCreator.EditProp))]
    internal static class Patch_CreatorUi
    {
        private static void Postfix(CharacterCreator __instance)
        {
            CameraReset.CaptureHome();              // record the camera's default pose on first open (for reset)
            ImportButton.Ensure(__instance);
            MassImportButton.Ensure(__instance);   // P1 — "Importar Pasta" (import em massa)
            SharedFolderImportButton.Ensure(__instance); // "Importar Pasta (texturas compartilhadas)" — recursivo + auto-rota
            RandomButton.Ensure(__instance);       // P15 — "Aleatório" (sorteia só peças custom)
            PaintButton.Ensure(__instance);        // "Pincel" — pinta a textura da peça (salva como variante nova)
            ResetCamButton.Ensure(__instance);     // "Resetar câmera" — volta a câmera do criador ao padrão
            CustomFilterButton.Ensure(__instance); // P9 — "Só custom" toggle
            TagBar.Ensure(__instance);             // P10 — barra de tags "+ / chips", ao lado do "Só custom"
            CustomCategories.EnsureAll(__instance); // "Olhos" sub-tab category button
            ShoeButton.Ensure(__instance);          // "Sapato" button (shown only in the feet category)
            NavArrows.Ensure(__instance);          // P12 — ◀ ▶ step through category options
            ZoomButtons.Ensure(__instance);        // + / – zoom beside the arrows
            PanButtons.Ensure(__instance);         // ▲ / ▼ raise/lower the camera (left of the model)
            PersistenceLoader.LoadAll(__instance); // rebuild saved models (once per session)
        }
    }

    /// <summary>
    /// After each character tab item button is initialized, add a delete (trash) button to the
    /// custom ones so old imported models can be removed from the list.
    /// </summary>
    [HarmonyPatch(typeof(BuildTabsLoader_Characters), "InitialiseDataItemButton")]
    internal static class Patch_ItemTrash
    {
        private static void Postfix(BuildTabsButton button, string id)
        {
            IconButton.Apply(button, id); // P7 — show the snapshot portrait instead of the name
            TrashButton.Apply(button, id);
            EditButton.Apply(button, id); // P6 — reopen the edit panel for custom parts
        }
    }

    /// <summary>
    /// Blocks camera drag rotation when modeling mode is active and the user is dragging
    /// with the left mouse button (to prevent camera rotation from competing with the modeling drag).
    /// Right/Middle mouse drags still work.
    /// </summary>
    [HarmonyPatch(typeof(CharacterCreatorCamera), "MouseDrag")]
    internal static class ScaleCameraDragGuard
    {
        private static bool Prefix(UnityEngine.EventSystems.PointerEventData mouse)
        {
            if (ScaleSession.IsModeling)
            {
                if (mouse != null && mouse.button == UnityEngine.EventSystems.PointerEventData.InputButton.Left)
                    return false;
            }
            return true;
        }
    }

    /// <summary>
    /// Hide the VariantBar when the CharacterCreator is disabled or destroyed.
    /// This prevents the variant selection UI from getting stuck on the screen when returning to the game.
    /// </summary>
    [HarmonyPatch(typeof(CharacterCreator), "OnDisable")]
    internal static class Patch_CharacterCreator_OnDisable
    {
        private static void Postfix()
        {
            VariantBar.Hide();
        }
    }

    [HarmonyPatch(typeof(CharacterCreator), "OnDestroy")]
    internal static class Patch_CharacterCreator_OnDestroy
    {
        private static void Postfix()
        {
            VariantBar.Hide();
        }
    }
}
